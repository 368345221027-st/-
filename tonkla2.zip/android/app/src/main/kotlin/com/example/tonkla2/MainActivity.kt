package com.example.tonkla2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
