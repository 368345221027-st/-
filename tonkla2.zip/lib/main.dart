import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

// ---------------------------------------------------------------
// Model: ข้อมูลสินค้าในตะกร้า (เทียบได้กับ struct CartItem ใน SwiftUI)
// ---------------------------------------------------------------
class CartItem {
  final String id;
  final String name;
  final double price; // ราคาต่อชิ้น
  int quantity; // จำนวน (แก้ไขได้)

  CartItem({
    required this.id,
    required this.name,
    required this.price,
    this.quantity = 1,
  });

  double get total => price * quantity; // ราคารวมของรายการนี้
}

// ---------------------------------------------------------------
// ฟังก์ชันจัดรูปแบบเงินบาท เช่น 1890 -> ฿1,890.00
// เขียนเองเพื่อไม่ต้องเพิ่มแพ็กเกจ intl ใน FlutLab
// ---------------------------------------------------------------
String formatBaht(double value) {
  final parts = value.toStringAsFixed(2).split('.');
  // แทรกคอมมาทุก 3 หลัก
  final intPart = parts[0].replaceAllMapped(
    RegExp(r'\B(?=(\d{3})+(?!\d))'),
    (m) => ',',
  );
  return '฿$intPart.${parts[1]}';
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Shopping Cart',
      theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
      home: const CartPage(),
    );
  }
}

// ---------------------------------------------------------------
// หน้าตะกร้า: ใช้ StatefulWidget + setState
// (เทียบได้กับ @State var items ใน SwiftUI)
// ---------------------------------------------------------------
class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  // ข้อมูลภายในแอป ไม่ใช้ API / ฐานข้อมูล
  final List<CartItem> _items = [
    CartItem(id: '1', name: 'รองเท้าวิ่ง', price: 1890, quantity: 1),
    CartItem(id: '2', name: 'เสื้อยืดคอตตอน', price: 350, quantity: 2),
    CartItem(id: '3', name: 'กระเป๋าเป้', price: 1290.50, quantity: 1),
    CartItem(id: '4', name: 'ขวดน้ำสแตนเลส', price: 249, quantity: 3),
    CartItem(id: '5', name: 'หูฟังบลูทูธ', price: 990, quantity: 1),
  ];

  // จำนวนสินค้ารวมทุกชิ้น (คำนวณใหม่ทุกครั้งที่ build จึงอัปเดตทันที)
  int get _totalQty => _items.fold(0, (sum, i) => sum + i.quantity);

  // ราคารวมทั้งหมด
  double get _totalPrice => _items.fold(0.0, (sum, i) => sum + i.total);

  // เพิ่มจำนวน
  void _increase(CartItem item) {
    setState(() => item.quantity++);
  }

  // ลดจำนวน แต่ต้องไม่ต่ำกว่า 1
  void _decrease(CartItem item) {
    if (item.quantity > 1) {
      setState(() => item.quantity--);
    }
  }

  // ลบสินค้า
  void _remove(CartItem item) {
    setState(() => _items.remove(item));
  }

  // กด Checkout
  void _checkout() {
    final msg = 'ชำระเงิน ${formatBaht(_totalPrice)} เรียบร้อย';
    setState(() => _items.clear()); // ล้างตะกร้าหลังชำระเงิน
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ตะกร้าสินค้า')),

      // ถ้าตะกร้าว่างให้แสดง Empty State
      body: _items.isEmpty
          ? const _EmptyState()
          : ListView.builder(
              // เทียบกับ List ใน SwiftUI
              itemCount: _items.length,
              itemBuilder: (context, index) {
                final item = _items[index];

                // Dismissible = Swipe to Delete (ปัดซ้ายเพื่อลบ)
                return Dismissible(
                  key: ValueKey(item.id), // ต้องมี key ที่ไม่ซ้ำกัน
                  direction: DismissDirection.endToStart,
                  onDismissed: (_) => _remove(item),
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 24),
                    child: const Icon(Icons.delete, color: Colors.white),
                  ),
                  child: CartItemRow(
                    item: item,
                    onIncrease: () => _increase(item),
                    onDecrease: () => _decrease(item),
                  ),
                );
              },
            ),

      // ส่วนสรุปด้านล่างหน้าจอ
      bottomNavigationBar: _SummaryBar(
        totalQty: _totalQty,
        totalPrice: _totalPrice,
        // ส่ง null = ปุ่มกดไม่ได้ เมื่อตะกร้าว่าง
        onCheckout: _items.isEmpty ? null : _checkout,
      ),
    );
  }
}

// ---------------------------------------------------------------
// CartItemRow: แยกแต่ละแถวออกมาเป็น Widget ของตัวเอง (Bonus)
// ---------------------------------------------------------------
class CartItemRow extends StatelessWidget {
  final CartItem item;
  final VoidCallback onIncrease;
  final VoidCallback onDecrease;

  const CartItemRow({
    super.key,
    required this.item,
    required this.onIncrease,
    required this.onDecrease,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Theme.of(context).colorScheme.surface, // กันพื้นหลังโปร่งตอนปัด
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          // ฝั่งซ้าย: ชื่อ + ราคาต่อชิ้น
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.name,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Text('${formatBaht(item.price)} / ชิ้น',
                    style: TextStyle(color: Colors.grey.shade600)),
                const SizedBox(height: 4),
                // ราคารวมของรายการนี้
                Text('รวม ${formatBaht(item.total)}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ),

          // ฝั่งขวา: ปุ่ม − จำนวน +
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.remove_circle_outline),
                // เมื่อจำนวน <= 1 ให้ปุ่มกดไม่ได้ (null)
                onPressed: item.quantity > 1 ? onDecrease : null,
              ),
              // Animation: ตัวเลขเปลี่ยนด้วยเอฟเฟกต์ขยาย/หด (Bonus)
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                transitionBuilder: (child, anim) =>
                    ScaleTransition(scale: anim, child: child),
                child: Text(
                  '${item.quantity}',
                  key: ValueKey(item.quantity), // key เปลี่ยน = เล่น animation
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.add_circle_outline),
                onPressed: onIncrease,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------
// แถบสรุปด้านล่าง: จำนวนรวม + ราคารวม + ปุ่ม Checkout
// ---------------------------------------------------------------
class _SummaryBar extends StatelessWidget {
  final int totalQty;
  final double totalPrice;
  final VoidCallback? onCheckout;

  const _SummaryBar({
    required this.totalQty,
    required this.totalPrice,
    required this.onCheckout,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 8,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('จำนวนสินค้ารวม'),
                  Text('$totalQty ชิ้น'),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('ราคารวมทั้งหมด',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  Text(formatBaht(totalPrice),
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: onCheckout, // null = disabled อัตโนมัติ
                  child: const Text('Checkout'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------
// Empty State: แสดงเมื่อตะกร้าว่าง
// ---------------------------------------------------------------
class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.shopping_cart_outlined,
              size: 72, color: Colors.grey.shade400),
          const SizedBox(height: 12),
          Text('ตะกร้าของคุณยังว่างอยู่',
              style: TextStyle(fontSize: 16, color: Colors.grey.shade600)),
        ],
      ),
    );
  }
}
