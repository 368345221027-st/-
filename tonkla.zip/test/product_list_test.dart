import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
// ถ้าชื่อ project ใน pubspec.yaml ไม่ใช่ searchable_product_list ให้แก้ชื่อ package ตรงนี้
import 'package:searchable_product_list/screens/product_list_screen.dart';
import 'package:searchable_product_list/services/product_service.dart';

Widget _buildApp(ProductService service) {
  return MaterialApp(home: ProductListScreen(service: service));
}

void main() {
  testWidgets('Search + Category filter work together', (tester) async {
    await tester.pumpWidget(
      _buildApp(MockProductService(delay: Duration.zero)),
    );
    await tester.pumpAndSettle();

    // เลือกหมวด Accessories
    await tester.tap(find.widgetWithText(ChoiceChip, 'Accessories'));
    await tester.pumpAndSettle();

    // ค้นหา "keyboard" (รอ debounce 300ms)
    await tester.enterText(find.byType(TextField), 'keyboard');
    await tester.pump(const Duration(milliseconds: 400));
    await tester.pumpAndSettle();

    expect(find.text('Mechanical Keyboard'), findsOneWidget);
    expect(find.text('Wireless Keyboard'), findsOneWidget);
    expect(find.text('Gaming Mouse'), findsNothing);
    expect(find.text('2 result(s)'), findsOneWidget);
  });

  testWidgets('Shows Empty state when no product matches', (tester) async {
    await tester.pumpWidget(
      _buildApp(MockProductService(delay: Duration.zero)),
    );
    await tester.pumpAndSettle();

    await tester.enterText(find.byType(TextField), 'zzzzzz');
    await tester.pump(const Duration(milliseconds: 400));
    await tester.pumpAndSettle();

    expect(find.text('No products found'), findsOneWidget);
  });

  testWidgets('Shows Error then Retry loads data', (tester) async {
    await tester.pumpWidget(
      _buildApp(MockProductService(delay: Duration.zero, failFirstCall: true)),
    );
    await tester.pumpAndSettle();

    expect(find.text('Retry'), findsOneWidget);

    await tester.tap(find.text('Retry'));
    await tester.pumpAndSettle();

    expect(find.text('Retry'), findsNothing);
    expect(find.text('Mechanical Keyboard'), findsOneWidget);
  });
}
