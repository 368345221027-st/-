import 'package:flutter/material.dart';

import 'screens/product_list_screen.dart';
import 'services/product_service.dart';

void main() {
  runApp(const ProductApp());
}

class ProductApp extends StatefulWidget {
  const ProductApp({Key? key}) : super(key: key);

  @override
  State<ProductApp> createState() => _ProductAppState();
}

class _ProductAppState extends State<ProductApp> {
  ThemeMode _themeMode = ThemeMode.light;

  void _toggleTheme() {
    setState(() {
      _themeMode =
          _themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Searchable Product List',
      debugShowCheckedModeBanner: false,
      themeMode: _themeMode,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.indigo,
          brightness: Brightness.dark,
        ),
      ),
      home: ProductListScreen(
        // failFirstCall: true -> โหลดครั้งแรกจะ Error เพื่อโชว์ปุ่ม Retry
        // ถ้าไม่ต้องการ ให้เปลี่ยนเป็น false
        service: MockProductService(failFirstCall: true),
        isDark: _themeMode == ThemeMode.dark,
        onToggleTheme: _toggleTheme,
      ),
    );
  }
}
