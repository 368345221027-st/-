import 'dart:convert';

import '../models/product.dart';

class ProductLoadException implements Exception {
  final String message;
  const ProductLoadException(this.message);

  @override
  String toString() => message;
}

/// Interface ของ service เพื่อให้สลับเป็น API จริง หรือ fake ตอนเทสได้
abstract class ProductService {
  Future<List<Product>> fetchProducts();
}

/// จำลองการโหลดข้อมูลจาก server
class MockProductService implements ProductService {
  MockProductService({
    this.delay = const Duration(seconds: 1),
    this.failFirstCall = false,
  });

  final Duration delay;
  final bool failFirstCall;
  bool _hasFailed = false;

  @override
  Future<List<Product>> fetchProducts() async {
    await Future<void>.delayed(delay);

    if (failFirstCall && !_hasFailed) {
      _hasFailed = true;
      throw const ProductLoadException(
        'Could not load products. Please check your connection.',
      );
    }

    final decoded = jsonDecode(_rawJson) as List<dynamic>;
    return decoded
        .map((item) => Product.fromJson(item as Map<String, dynamic>))
        .toList();
  }
}

const String _rawJson = '''
[
  {"id": 1, "name": "Mechanical Keyboard", "price": 1890, "category": "Accessories", "inStock": true, "description": "Hot-swappable mechanical keyboard with blue switches and RGB backlight."},
  {"id": 2, "name": "Wireless Keyboard", "price": 790, "category": "Accessories", "inStock": false, "description": "Slim wireless keyboard with 12-month battery life."},
  {"id": 3, "name": "Gaming Mouse", "price": 990, "category": "Accessories", "inStock": true, "description": "Lightweight 16000 DPI gaming mouse with 6 programmable buttons."},
  {"id": 4, "name": "USB-C Hub 7-in-1", "price": 1290, "category": "Accessories", "inStock": true, "description": "HDMI, USB 3.0, SD card reader and 100W pass-through charging."},
  {"id": 5, "name": "Laptop 14 inch", "price": 25900, "category": "Computers", "inStock": true, "description": "14 inch laptop, 16GB RAM, 512GB SSD."},
  {"id": 6, "name": "Desktop PC Tower", "price": 32900, "category": "Computers", "inStock": false, "description": "Tower PC for work and gaming."},
  {"id": 7, "name": "27 inch 4K Monitor with Ultra Wide Color Gamut and Height Adjustable Stand", "price": 12900, "category": "Computers", "inStock": true, "description": "4K IPS monitor with USB-C input, height adjustable stand and built-in speakers."},
  {"id": 8, "name": "Noise Cancelling Headphones", "price": 5990, "category": "Audio", "inStock": true, "description": "Over-ear headphones with active noise cancelling and 30-hour battery."},
  {"id": 9, "name": "Bluetooth Speaker", "price": 1590, "category": "Audio", "inStock": false, "description": "Portable waterproof speaker."},
  {"id": 10, "name": "Smartphone 128GB", "price": 15900, "category": "Mobile", "inStock": true, "description": "6.5 inch OLED display, 128GB storage, dual camera."},
  {"id": 11, "name": "Tablet 10 inch", "price": 8900, "category": "Mobile", "inStock": true, "description": "10 inch tablet for reading and note taking."},
  {"id": 12, "name": "Phone Case", "price": 290, "category": "Mobile", "inStock": true, "description": "Shockproof transparent phone case."}
]
''';
