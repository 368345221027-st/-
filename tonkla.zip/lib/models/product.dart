class Product {
  final int id;
  final String name;
  final double price;
  final String category;
  final bool inStock;
  final String description;

  const Product({
    required this.id,
    required this.name,
    required this.price,
    required this.category,
    required this.inStock,
    required this.description,
  });

  /// แปลง JSON (Map) เป็น Product ที่มี type ชัดเจนทุก field
  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'] as int,
      name: json['name'] as String,
      price: (json['price'] as num).toDouble(),
      category: json['category'] as String,
      inStock: json['inStock'] as bool,
      description: (json['description'] as String?) ?? '',
    );
  }

  /// เช่น 1890 -> ฿1,890
  String get priceText {
    final digits = price.toStringAsFixed(0);
    final withCommas = digits.replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (match) => ',',
    );
    return '฿$withCommas';
  }
}
