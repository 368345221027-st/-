import 'package:flutter/material.dart';

class StockBadge extends StatelessWidget {
  final bool inStock;

  const StockBadge({Key? key, required this.inStock}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final color = inStock ? Colors.green : Colors.red;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(inStock ? Icons.check_circle : Icons.cancel,
            size: 16, color: color),
        const SizedBox(width: 4),
        Text(
          inStock ? 'In stock' : 'Out of stock',
          style: TextStyle(color: color, fontWeight: FontWeight.w600),
        ),
      ],
    );
  }
}
