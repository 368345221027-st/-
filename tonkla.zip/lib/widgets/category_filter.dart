import 'package:flutter/material.dart';

/// แถวปุ่มเลือกหมวดหมู่ (เลื่อนซ้าย-ขวาได้เมื่อจอแคบ)
class CategoryFilter extends StatelessWidget {
  final List<String> categories;
  final String? selected; // null = All
  final ValueChanged<String?> onSelected;

  const CategoryFilter({
    Key? key,
    required this.categories,
    required this.selected,
    required this.onSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: ChoiceChip(
              label: const Text('All'),
              selected: selected == null,
              onSelected: (_) => onSelected(null),
            ),
          ),
          for (final category in categories)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: ChoiceChip(
                label: Text(category),
                selected: selected == category,
                onSelected: (_) => onSelected(category),
              ),
            ),
        ],
      ),
    );
  }
}
