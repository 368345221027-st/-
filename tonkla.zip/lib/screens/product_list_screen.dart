import 'dart:async';

import 'package:flutter/material.dart';

import '../models/product.dart';
import '../services/product_service.dart';
import '../widgets/category_filter.dart';
import '../widgets/product_card.dart';
import '../widgets/state_views.dart';
import 'product_detail_screen.dart';

enum LoadStatus { loading, error, data }

enum SortOption { none, priceLowToHigh, priceHighToLow }

class ProductListScreen extends StatefulWidget {
  final ProductService service;
  final bool isDark;
  final VoidCallback? onToggleTheme;

  const ProductListScreen({
    Key? key,
    required this.service,
    this.isDark = false,
    this.onToggleTheme,
  }) : super(key: key);

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  final TextEditingController _searchController = TextEditingController();
  Timer? _debounce;

  LoadStatus _status = LoadStatus.loading;
  String _errorMessage = '';
  List<Product> _allProducts = [];

  String _query = '';
  String? _selectedCategory; // null = All
  SortOption _sort = SortOption.none;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController.dispose(); // ต้อง dispose controller
    super.dispose();
  }

  Future<void> _fetch() async {
    try {
      final products = await widget.service.fetchProducts();
      if (!mounted) return;
      setState(() {
        _allProducts = products;
        _status = LoadStatus.data;
      });
    } on ProductLoadException catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = e.message;
        _status = LoadStatus.error;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Something went wrong.';
        _status = LoadStatus.error;
      });
    }
  }

  void _retry() {
    setState(() => _status = LoadStatus.loading);
    _fetch();
  }

  void _onSearchChanged(String value) {
    setState(() {}); // อัปเดตปุ่ม clear ทันที
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () {
      if (!mounted) return;
      setState(() => _query = value);
    });
  }

  void _clearSearch() {
    _debounce?.cancel();
    _searchController.clear();
    setState(() => _query = '');
  }

  List<String> get _categories {
    final set = <String>{for (final p in _allProducts) p.category};
    final list = set.toList()..sort();
    return list;
  }

  /// Search + Category ทำงานร่วมกัน (ต้องผ่านทั้งสองเงื่อนไข)
  List<Product> get _filteredProducts {
    final q = _query.trim().toLowerCase();
    final result = _allProducts.where((p) {
      final matchCategory =
          _selectedCategory == null || p.category == _selectedCategory;
      final matchName = q.isEmpty || p.name.toLowerCase().contains(q);
      return matchCategory && matchName;
    }).toList();

    switch (_sort) {
      case SortOption.priceLowToHigh:
        result.sort((a, b) => a.price.compareTo(b.price));
        break;
      case SortOption.priceHighToLow:
        result.sort((a, b) => b.price.compareTo(a.price));
        break;
      case SortOption.none:
        break;
    }
    return result;
  }

  void _openDetail(Product product) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ProductDetailScreen(product: product),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Products'),
        actions: [
          PopupMenuButton<SortOption>(
            icon: const Icon(Icons.sort),
            tooltip: 'Sort by price',
            initialValue: _sort,
            onSelected: (value) => setState(() => _sort = value),
            itemBuilder: (_) => const [
              PopupMenuItem(value: SortOption.none, child: Text('Default')),
              PopupMenuItem(
                  value: SortOption.priceLowToHigh,
                  child: Text('Price: Low to High')),
              PopupMenuItem(
                  value: SortOption.priceHighToLow,
                  child: Text('Price: High to Low')),
            ],
          ),
          if (widget.onToggleTheme != null)
            IconButton(
              tooltip: 'Toggle dark mode',
              icon: Icon(widget.isDark ? Icons.light_mode : Icons.dark_mode),
              onPressed: widget.onToggleTheme,
            ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    switch (_status) {
      case LoadStatus.loading:
        return const Center(child: CircularProgressIndicator());
      case LoadStatus.error:
        return ErrorView(message: _errorMessage, onRetry: _retry);
      case LoadStatus.data:
        return _buildData();
    }
  }

  Widget _buildData() {
    final products = _filteredProducts;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
          child: TextField(
            controller: _searchController,
            onChanged: _onSearchChanged,
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              hintText: 'Search by product name',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _searchController.text.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: _clearSearch,
                    ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
        CategoryFilter(
          categories: _categories,
          selected: _selectedCategory,
          onSelected: (value) => setState(() => _selectedCategory = value),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text('${products.length} result(s)'),
          ),
        ),
        Expanded(
          child: products.isEmpty
              ? const EmptyView()
              : ListView.builder(
                  itemCount: products.length,
                  itemBuilder: (context, index) {
                    final product = products[index];
                    return ProductCard(
                      product: product,
                      onTap: () => _openDetail(product),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
