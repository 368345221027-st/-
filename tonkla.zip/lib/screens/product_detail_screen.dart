import 'package:flutter/material.dart';

import '../models/product.dart';
import '../widgets/stock_badge.dart';

class ProductDetailScreen extends StatelessWidget {
  final Product product;

  const ProductDetailScreen({Key? key, required this.product})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Product Details')),
      // ใช้ ListView เพื่อให้เลื่อนได้ ไม่ overflow เมื่อจอเล็ก/ข้อความยาว
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(product.name, style: textTheme.headlineSmall),
          const SizedBox(height: 12),
          Text(
            product.priceText,
            style:
                textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 12,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Chip(label: Text(product.category)),
              StockBadge(inStock: product.inStock),
            ],
          ),
          const SizedBox(height: 24),
          Text('Description', style: textTheme.titleMedium),
          const SizedBox(height: 8),
          Text(product.description.isEmpty
              ? 'No description.'
              : product.description),
        ],
      ),
    );
  }
}
