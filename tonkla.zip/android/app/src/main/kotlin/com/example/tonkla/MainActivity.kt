package com.example.tonkla

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
