package com.example.tonkla3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
