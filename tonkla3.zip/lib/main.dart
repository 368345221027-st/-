import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

// ---------- 1) ส่วน Logic (แยกจาก UI เพื่อให้ทดสอบง่าย) ----------

/// หน่วยอุณหภูมิ 3 หน่วย
enum TempUnit { celsius, fahrenheit, kelvin }

extension TempUnitInfo on TempUnit {
  /// ชื่อที่แสดงใน Dropdown
  String get label {
    switch (this) {
      case TempUnit.celsius:
        return 'Celsius (°C)';
      case TempUnit.fahrenheit:
        return 'Fahrenheit (°F)';
      case TempUnit.kelvin:
        return 'Kelvin (K)';
    }
  }

  /// สัญลักษณ์ที่ต่อท้ายผลลัพธ์
  String get symbol {
    switch (this) {
      case TempUnit.celsius:
        return '°C';
      case TempUnit.fahrenheit:
        return '°F';
      case TempUnit.kelvin:
        return 'K';
    }
  }

  /// ค่า Absolute Zero ของแต่ละหน่วย (ต่ำกว่านี้ไม่ได้)
  double get absoluteZero {
    switch (this) {
      case TempUnit.celsius:
        return -273.15;
      case TempUnit.fahrenheit:
        return -459.67;
      case TempUnit.kelvin:
        return 0;
    }
  }
}

/// แปลงหน่วยใดๆ -> Celsius (ใช้ Celsius เป็นตัวกลาง)
double toCelsius(double v, TempUnit u) {
  switch (u) {
    case TempUnit.celsius:
      return v;
    case TempUnit.fahrenheit:
      return (v - 32) * 5 / 9;
    case TempUnit.kelvin:
      return v - 273.15;
  }
}

/// แปลง Celsius -> หน่วยปลายทาง
double fromCelsius(double c, TempUnit u) {
  switch (u) {
    case TempUnit.celsius:
      return c;
    case TempUnit.fahrenheit:
      return c * 9 / 5 + 32;
    case TempUnit.kelvin:
      return c + 273.15;
  }
}

/// ฟังก์ชันแปลงหลัก: หน่วยเดียวกันคืนค่าเดิม, อื่นๆ แปลงผ่าน Celsius
double convert(double v, TempUnit from, TempUnit to) {
  if (from == to) return v;
  return fromCelsius(toCelsius(v, from), to);
}

// ---------- 2) ส่วน UI ----------

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Temperature Converter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.deepOrange),
      home: const ConverterPage(),
    );
  }
}

class ConverterPage extends StatefulWidget {
  const ConverterPage({super.key});

  @override
  State<ConverterPage> createState() => _ConverterPageState();
}

class _ConverterPageState extends State<ConverterPage> {
  // controller เก็บข้อความในช่องกรอก (เปลี่ยนหน่วยแล้วค่าไม่หาย)
  final TextEditingController _controller = TextEditingController();
  TempUnit _from = TempUnit.celsius;
  TempUnit _to = TempUnit.fahrenheit;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// สลับหน่วยต้นทาง <-> ปลายทาง (ไม่แตะ input)
  void _swap() {
    setState(() {
      final tmp = _from;
      _from = _to;
      _to = tmp;
    });
  }

  /// Bonus: ปุ่ม Reset
  void _reset() {
    setState(() {
      _controller.clear();
      _from = TempUnit.celsius;
      _to = TempUnit.fahrenheit;
    });
  }

  /// คำนวณผลลัพธ์จาก state ปัจจุบัน
  /// คืนค่า (ผลลัพธ์, ข้อความ error) — อย่างใดอย่างหนึ่งเป็น null
  ({String? result, String? error}) _compute() {
    // รองรับคนพิมพ์ "," แทน "." และตัดช่องว่าง
    final text = _controller.text.trim().replaceAll(',', '.');

    if (text.isEmpty) {
      return (result: null, error: 'กรุณากรอกค่าอุณหภูมิ');
    }

    // tryParse คืน null ถ้าไม่ใช่ตัวเลข (เช่น "abc", "-") ไม่ throw => ไม่ crash
    final value = double.tryParse(text);
    if (value == null || value.isNaN || value.isInfinite) {
      return (result: null, error: 'กรุณากรอกตัวเลขที่ถูกต้อง');
    }

    // ตรวจ Absolute Zero ตามหน่วยต้นทาง
    if (value < _from.absoluteZero) {
      return (
        result: null,
        error:
            'ค่าต่ำกว่า Absolute Zero (ต่ำสุด ${_from.absoluteZero} ${_from.symbol})'
      );
    }

    var out = convert(value, _from, _to);
    // กัน "-0.00" (เช่น -0.0000001 ปัดเป็น -0.00)
    if (out.abs() < 0.005) out = 0;
    return (result: '${out.toStringAsFixed(2)} ${_to.symbol}', error: null);
  }

  /// Dropdown เลือกหน่วย ใช้ซ้ำทั้งต้นทางและปลายทาง
  Widget _unitDropdown(
      String label, TempUnit value, ValueChanged<TempUnit> onChanged) {
    return Expanded(
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<TempUnit>(
            value: value,
            isExpanded: true,
            isDense: true,
            items: TempUnit.values
                .map((u) => DropdownMenuItem(value: u, child: Text(u.label)))
                .toList(),
            onChanged: (u) {
              if (u != null) setState(() => onChanged(u));
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // คำนวณใหม่ทุกครั้งที่ build => ผลลัพธ์เปลี่ยนทันทีเมื่อค่าหรือหน่วยเปลี่ยน
    final r = _compute();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Temperature Converter'),
        actions: [
          IconButton(
            tooltip: 'Reset',
            icon: const Icon(Icons.refresh),
            onPressed: _reset,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // ช่องกรอก: รองรับทศนิยมและติดลบ
            TextField(
              controller: _controller,
              keyboardType: const TextInputType.numberWithOptions(
                  decimal: true, signed: true),
              decoration: InputDecoration(
                labelText: 'อุณหภูมิ',
                border: const OutlineInputBorder(),
                // แสดง error ใต้ช่องกรอกเมื่อมีข้อผิดพลาด
                errorText: r.error,
              ),
              onChanged: (_) => setState(() {}), // สั่งคำนวณใหม่ทันที
            ),
            const SizedBox(height: 16),

            // แถวเลือกหน่วย + ปุ่มสลับ
            Row(
              children: [
                _unitDropdown('จาก', _from, (u) => _from = u),
                IconButton(
                  tooltip: 'สลับหน่วย',
                  icon: const Icon(Icons.swap_horiz),
                  onPressed: _swap,
                ),
                _unitDropdown('ไปยัง', _to, (u) => _to = u),
              ],
            ),
            const SizedBox(height: 24),

            // การ์ดแสดงผลลัพธ์
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const Text('ผลลัพธ์'),
                    const SizedBox(height: 8),
                    Text(
                      r.result ?? '—',
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
